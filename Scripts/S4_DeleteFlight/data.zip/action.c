Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("hp_logo.png", 
		"URL=http://localhost:1080/WebTours/images/hp_logo.png", 
		"Resource=1", 
		"Referer=http://localhost:1080/WebTours/header.html", 
		"Snapshot=t26.inf", 
		LAST);

	web_url("webtours.png", 
		"URL=http://localhost:1080/WebTours/images/webtours.png", 
		"Resource=1", 
		"Referer=http://localhost:1080/WebTours/header.html", 
		"Snapshot=t27.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(5);

	web_submit_form("login.pl", 
		"Snapshot=t28.inf", 
		ITEMDATA, 
		"Name=username", "Value=ivan", ENDITEM, 
		"Name=password", "Value=ivan", ENDITEM, 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_image("Itinerary Button", 
		"Alt=Itinerary Button", 
		"Snapshot=t29.inf", 
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");

	web_submit_form("itinerary.pl", 
		"Snapshot=t30.inf", 
		ITEMDATA, 
		"Name=1", "Value=<OFF>", ENDITEM, 
		"Name=2", "Value=on", ENDITEM, 
		"Name=3", "Value=<OFF>", ENDITEM, 
		"Name=4", "Value=<OFF>", ENDITEM, 
		"Name=5", "Value=<OFF>", ENDITEM, 
		"Name=6", "Value=<OFF>", ENDITEM, 
		LAST);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t31.inf", 
		LAST);

	return 0;
}